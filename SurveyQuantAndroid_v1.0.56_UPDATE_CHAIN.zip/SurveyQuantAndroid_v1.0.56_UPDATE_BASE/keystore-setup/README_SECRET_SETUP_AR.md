# إعداد توقيع سلسلة تحديث SurveyQuant

هذه النسخة تستخدم مفتاح Release ثابتًا. لا ترفع ملف JKS إلى GitHub Repository.

أضف القيم التالية في GitHub:
Settings → Secrets and variables → Actions → New repository secret

1. SURVEYQUANT_KEYSTORE_BASE64
   القيمة: محتوى ملف `surveyquant-release.base64.txt`

2. SURVEYQUANT_KEYSTORE_PASSWORD
   القيمة: `SqRelease2026!A9`

3. SURVEYQUANT_KEY_ALIAS
   القيمة: `surveyquant_release`

4. SURVEYQUANT_KEY_PASSWORD
   القيمة: `SqRelease2026!A9`

بعد إضافة الأسرار شغّل:
Actions → Build SurveyQuant v1.0.56 Release → Run workflow

مهم: احتفظ بهذه الأسرار، ولا تغير المفتاح في أي إصدار لاحق.
